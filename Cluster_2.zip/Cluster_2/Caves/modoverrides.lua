return {
  ["workshop-1185229307"]={
    configuration_options={ [""]="", damage=true, noepic=false, nonoepic=false, offset=0 },
    enabled=true 
  },
  ["workshop-1207269058"]={ configuration_options={  }, enabled=true },
  ["workshop-1324291086"]={ configuration_options={  }, enabled=true },
  ["workshop-1371577149"]={ configuration_options={ BUILD_SPACING=3.2 }, enabled=true },
  ["workshop-1530801499"]={
    configuration_options={ Hunger_Cost=1, Ownership=false, Sanity_Cost=1 },
    enabled=true 
  },
  ["workshop-356420397"]={ configuration_options={  }, enabled=true },
  ["workshop-362175979"]={ configuration_options={ ["Draw over FoW"]="disabled" }, enabled=true },
  ["workshop-363112314"]={ configuration_options={  }, enabled=true },
  ["workshop-374550642"]={ configuration_options={ MAXSTACKSIZE=99 }, enabled=true },
  ["workshop-375850593"]={ configuration_options={  }, enabled=true },
  ["workshop-378160973"]={
    configuration_options={
      ENABLEPINGS=true,
      FIREOPTIONS=2,
      OVERRIDEMODE=false,
      SHAREMINIMAPPROGRESS=true,
      SHOWFIREICONS=true,
      SHOWPLAYERICONS=true,
      SHOWPLAYERSOPTIONS=2 
    },
    enabled=true 
  },
  ["workshop-438293817"]={ configuration_options={  }, enabled=true },
  ["workshop-447092740"]={ configuration_options={  }, enabled=true },
  ["workshop-458940297"]={
    configuration_options={
      DFV_ClientPrediction="default",
      DFV_FueledSettings="default",
      DFV_Language="EN",
      DFV_MinimalMode="default",
      DFV_PercentReplace="default",
      DFV_ShowACondition="default",
      DFV_ShowADefence="default",
      DFV_ShowAType="default",
      DFV_ShowDamage="default",
      DFV_ShowFireTime="default",
      DFV_ShowInsulation="default",
      DFV_ShowTemperature="default",
      DFV_ShowUses="default" 
    },
    enabled=true 
  },
  ["workshop-462434129"]={
    configuration_options={
      MOD_RESTART_ALLOW_KILL=true,
      MOD_RESTART_ALLOW_RESTART=true,
      MOD_RESTART_ALLOW_RESURRECT=true,
      MOD_RESTART_CD_BONUS=0,
      MOD_RESTART_CD_KILL=3,
      MOD_RESTART_CD_MAX=0,
      MOD_RESTART_CD_RESTART=5,
      MOD_RESTART_CD_RESURRECT=7,
      MOD_RESTART_FORCE_DROP_MODE=0,
      MOD_RESTART_IGNORING_ADMIN=true,
      MOD_RESTART_MAP_SAVE=2,
      MOD_RESTART_RESURRECT_HEALTH=0,
      MOD_RESTART_TRIGGER_MODE=1,
      MOD_RESTART_WELCOME_TIPS=true,
      MOD_RESTART_WELCOME_TIPS_TIME=6 
    },
    enabled=true 
  },
  ["workshop-463740026"]={ configuration_options={ ownership=false }, enabled=true },
  ["workshop-466732225"]={ configuration_options={  }, enabled=true },
  ["workshop-501385076"]={
    configuration_options={
      quick_cook_on_fire=true,
      quick_harvest=true,
      quick_pick_cactus=true,
      quick_pick_plant_normal_ground=true 
    },
    enabled=true 
  },
  ["workshop-509723993"]={
    configuration_options={ health_enhance=1, health_regen=1, regen_value=50, wall_undeployable=0 },
    enabled=true 
  },
  ["workshop-604761020"]={
    configuration_options={
      RUOYINXIAN=false,
      SHENGDANSHI=false,
      baoshibaolv=1,
      blue_baoshi=1,
      er_shuoming=0,
      green_baoshi=1,
      huangjinbaolv=1,
      marble_suipian=1,
      orange_baoshi=1,
      purple_baoshi=1,
      red_baoshi=1,
      shishengzhang=0,
      shitoubaolv=1,
      thulecite_xiukuang=1,
      wajuecishu=2,
      yellow_baoshi=1,
      yi_shuoming=0 
    },
    enabled=true 
  },
  ["workshop-623749604"]={
    configuration_options={
      Craft="Normal",
      Destroyable="DestroyByAll",
      FoodSpoilage=1,
      Language="En",
      Position="Center",
      Slots=80 
    },
    enabled=true 
  },
  ["workshop-624883463"]={ configuration_options={ DropWholeStack=true, StackSize=10 }, enabled=true },
  ["workshop-659304077"]={
    configuration_options={
      jgbattackrange=2,
      jgbcanuseashammer=true,
      jgbcanuseasshovel=false,
      jgbdamage=70,
      jgbfiniteuses=600,
      jgblightintensity=0.3,
      jgblightradius=0.6,
      jgbmovespeedmul=1.2 
    },
    enabled=true 
  },
  ["workshop-661253977"]={
    configuration_options={ amudiao=true, baodiao=1, kong=0, nillots=0, rendiao=2, zbdiao=true },
    enabled=true 
  },
  ["workshop-700236083"]={
    configuration_options={
      berrybush=1,
      berrybush2=1,
      berrybush_juicy=2,
      blue_mushroom=0,
      build=2,
      cactus=1,
      carrot_planted=0,
      cave_banana_tree=1,
      cave_fern=0,
      cook=1,
      draw=1,
      flower=0,
      flower_cave=1,
      flower_cave_double=1,
      flower_cave_triple=1,
      flower_evil=0,
      grass=1,
      green_mushroom=0,
      harvest=1,
      heal=1,
      lichen=1,
      mandrake_planted=1,
      marsh_bush=1,
      oasis_cactus=1,
      red_mushroom=0,
      reeds=1,
      resetmine=1,
      sapling=1,
      statueglommer=1,
      tallbirdnest=1,
      tumbleweed=1,
      wormlight_plant=1 
    },
    enabled=true 
  },
  ["workshop-782961570"]={ configuration_options={ layout=1, position=0 }, enabled=true },
  ["workshop-786556008"]={
    configuration_options={ ENABLEBACKPACK=false, EXTRASLOT=0, INVENTORYSIZE=45 },
    enabled=true 
  },
  ["workshop-810443397"]={
    configuration_options={
      FRESH=false,
      GIVE=false,
      LANG=0,
      LIGHT=false,
      RECIPE=3,
      STACK=false,
      WALKSPEED=0.75 
    },
    enabled=true 
  },
  ["workshop-837284509"]={
    configuration_options={ Craft="Easy", Efficient="Yes", Language="Cn", TriggerRange="1" },
    enabled=true 
  } 
}